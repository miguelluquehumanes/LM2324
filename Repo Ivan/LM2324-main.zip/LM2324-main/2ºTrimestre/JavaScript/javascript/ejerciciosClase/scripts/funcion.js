/*Conjunto de funciones realizadas por el profe 
para el sitio web*/

function muestraPopup(){
    alert("Hola Hackers!!!!!")
}