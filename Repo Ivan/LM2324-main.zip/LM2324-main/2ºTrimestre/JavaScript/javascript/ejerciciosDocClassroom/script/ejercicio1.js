function validar(){

    let x = document.getElementById("usuario").value;
    let y = document.getElementById("contrasena").value;
    alert("Bienvenido usuario " + x + " con la contraseña " + y);
}